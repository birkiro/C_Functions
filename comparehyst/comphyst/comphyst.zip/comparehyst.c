#include "comparehyst.h"

bool comparehyst(float input, int limit, int hyst)
{
    out_old = false;

    if(input >= limit) out_old = true;
    if((input < limit) && (input >= (limit-hyst))) out_old = true;
    else out_old = false;

    return out_old;
}
