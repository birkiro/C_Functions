#include <stdbool.h>

static bool out_old;

bool comparehyst(float input, int limit, int hyst);
